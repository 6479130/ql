export const version = 'v2.8.2';
export const changeLog = 'https://t.me/jiaolongwang/129';
